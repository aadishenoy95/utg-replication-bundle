param(
    [Parameter(Mandatory = $true)]
    [string]$DataDir,
    [string]$PythonCmd = "python"
)

$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Here

if (-not (Test-Path -LiteralPath $DataDir)) {
    throw "Data directory not found: $DataDir"
}

$venvPython = Join-Path $Here ".venv\Scripts\python.exe"

if (-not (Test-Path -LiteralPath $venvPython)) {
    Write-Host "Creating clean virtual environment..."
    & $PythonCmd -m venv ".venv"
}

Write-Host "Installing bundle requirements..."
& $venvPython -m pip install -r ".\requirements.txt"

Write-Host "Verifying frozen bundle files..."
$hashLines = Get-Content ".\SHA256SUMS.txt" | Where-Object { $_.Trim() -ne "" }
foreach ($line in $hashLines) {
    $parts = $line -split "\s+", 2
    if ($parts.Count -ne 2) {
        throw "Bad checksum line: $line"
    }
    $expected = $parts[0].Trim().ToUpperInvariant()
    $file = $parts[1].Trim()
    if ($file -eq "SHA256SUMS.txt") {
        continue
    }
    $full = Join-Path $Here $file
    if (-not (Test-Path -LiteralPath $full)) {
        throw "Missing frozen file: $file"
    }
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $full).Hash.ToUpperInvariant()
    if ($actual -ne $expected) {
        throw "Checksum mismatch for $file"
    }
}

Write-Host "Running all frozen UTG laws..."
& ".\RUN_ALL_UTG_LAWS.ps1" -DataDir $DataDir -PythonExe $venvPython

Write-Host ""
Write-Host "Bundle run complete."
