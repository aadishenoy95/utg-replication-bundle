import argparse
import math
from pathlib import Path

import numpy as np
from scipy import signal

import utg_cross_detector_residual_test as cross


def rankdata(values):
    order = np.argsort(values)
    ranks = np.empty(len(values), dtype=np.float64)
    i = 0
    while i < len(values):
        j = i
        while j + 1 < len(values) and values[order[j + 1]] == values[order[i]]:
            j += 1
        rank = 0.5 * (i + j) + 1.0
        ranks[order[i : j + 1]] = rank
        i = j + 1
    return ranks


def spearman_rho(x, y):
    rx = rankdata(np.asarray(x, dtype=np.float64))
    ry = rankdata(np.asarray(y, dtype=np.float64))
    rx -= np.mean(rx)
    ry -= np.mean(ry)
    denom = math.sqrt(float(np.dot(rx, rx) * np.dot(ry, ry)))
    if denom == 0.0:
        return np.nan
    return float(np.dot(rx, ry) / denom)


def empirical_positive_correlation_pvalue(x, y, n_trials, seed):
    obs = spearman_rho(x, y)
    rng = np.random.default_rng(seed)
    ge = 0
    y = np.asarray(y, dtype=np.float64)
    for _ in range(n_trials):
        rho = spearman_rho(x, y[rng.permutation(len(y))])
        if rho >= obs:
            ge += 1
    return obs, (ge + 1.0) / (n_trials + 1.0)


def complex_impulse(seg, fs):
    dt = 1.0 / fs
    analytic = signal.hilbert(seg)
    d2 = np.gradient(np.gradient(analytic, dt), dt)
    phase_anchor = analytic / np.maximum(np.abs(analytic), 1e-30)
    q = np.trapezoid(d2 * np.conj(phase_anchor), dx=dt)
    return complex(q)


def event_delta_and_complex_impulse(base_dir, event_name, start_after=0.01, end_after=0.45):
    cfg = cross.EVENTS[event_name]
    event = cross.prepare_event(base_dir, event_name, cfg)
    row = cross.on_source_best(event)

    fs = event["fs"]
    start_idx = event["merger_idx"] + int(round(start_after * fs))
    end_idx = event["merger_idx"] + int(round(end_after * fs))
    h1_seg = event["h1"][start_idx:end_idx]
    l1_seg = event["l1"][start_idx:end_idx]

    q_h1 = complex_impulse(h1_seg, fs)
    q_l1 = complex_impulse(l1_seg, fs)
    predictor = abs(q_h1 - row["beta"] * q_l1) ** 2
    return {
        "event": event_name,
        "delta": row["delta"],
        "predictor": predictor,
        "beta": row["beta"],
        "tail_tau_s": row["tail_tau_s"],
        "amp": row["amp"],
        "q_h1_abs": abs(q_h1),
        "q_l1_abs": abs(q_l1),
        "q_h1_phase": math.atan2(q_h1.imag, q_h1.real),
        "q_l1_phase": math.atan2(q_l1.imag, q_l1.real),
    }


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Compare UTG cross-residual deltas against a complex curvature-impulse law "
            "that preserves phase information."
        )
    )
    parser.add_argument("--data-dir", default=".")
    parser.add_argument(
        "--events",
        nargs="*",
        default=[
            "GW170729",
            "GW170814",
            "GW170818",
            "GW190519_153544",
            "GW190521",
            "GW190929_012149",
            "GW190701_203306",
            "GW191109_010717",
            "GW191127_050227",
            "GW200224_222234",
            "GW200208_130117",
            "GW200216_220804",
            "GW200220_124850",
            "GW200225_060421",
            "GW150914",
            "GW151226",
            "GW170104",
            "GW170608",
            "GW170823",
            "GW200129_065458",
        ],
    )
    parser.add_argument("--n-trials", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=12345)
    args = parser.parse_args()

    base_dir = Path(args.data_dir)
    rows = [event_delta_and_complex_impulse(base_dir, e) for e in args.events]

    deltas = np.array([row["delta"] for row in rows], dtype=np.float64)
    predictors = np.array([row["predictor"] for row in rows], dtype=np.float64)
    rho, p = empirical_positive_correlation_pvalue(predictors, deltas, args.n_trials, args.seed)

    print("Corrected UTG complex impulse law:")
    print("Delta_UTG ~ |Q_H1 - beta * Q_L1|^2")
    print()
    print("Event ranking by observed cross-residual delta:")
    for row in sorted(rows, key=lambda item: item["delta"], reverse=True):
        print(
            f"{row['event']}: delta={row['delta']:.6e} predictor={row['predictor']:.6e} "
            f"beta={row['beta']:.3f} |Qh1|={row['q_h1_abs']:.6e} |Ql1|={row['q_l1_abs']:.6e} "
            f"ph_h1={row['q_h1_phase']:.3f} ph_l1={row['q_l1_phase']:.3f} "
            f"tail_tau={row['tail_tau_s']:.3f}s amp={row['amp']:.6e}"
        )
    print()
    print("Event ranking by complex-impulse predictor:")
    for row in sorted(rows, key=lambda item: item["predictor"], reverse=True):
        print(
            f"{row['event']}: predictor={row['predictor']:.6e} "
            f"delta={row['delta']:.6e} beta={row['beta']:.3f}"
        )
    print()
    print(f"spearman_rho={rho:.6e}")
    print(f"empirical_positive_correlation_p={p:.6e}")


if __name__ == "__main__":
    main()
