import argparse
import math
from pathlib import Path

import h5py
import numpy as np
from scipy import signal


EVENTS = {
    "GW170729": {
        "gps": 1185389807.3,
        "start_gps": 1185386496.0,
        "h1": "H-H1_GWOSC_O2_4KHZ_R1-1185386496-4096.hdf5",
        "l1": "L-L1_GWOSC_O2_4KHZ_R1-1185386496-4096.hdf5",
    },
    "GW170814": {
        "gps": 1186741861.5,
        "start_gps": 1186739813.0,
        "h1": "H-H1_LOSC_C00_4_V1-1186739813-4096.hdf5",
        "l1": "L-L1_LOSC_C00_4_V1-1186739813-4096.hdf5",
    },
    "GW170818": {
        "gps": 1187058327.1,
        "start_gps": 1187057664.0,
        "h1": "H-H1_GWOSC_O2_4KHZ_R1-1187057664-4096.hdf5",
        "l1": "L-L1_GWOSC_O2_4KHZ_R1-1187057664-4096.hdf5",
    },
    "GW150914": {
        "gps": 1126259462.422,
        "start_gps": 1126256640.0,
        "h1": "H-H1_LOSC_4_V1-1126256640-4096.hdf5",
        "l1": "L-L1_LOSC_4_V1-1126256640-4096.hdf5",
    },
    "GW151226": {
        "gps": 1135136350.648,
        "start_gps": 1135136228.0,
        "h1": "H-H1_LOSC_4_V2-1135136228-4096.hdf5",
        "l1": "L-L1_LOSC_4_V2-1135136228-4096.hdf5",
    },
    "GW170104": {
        "gps": 1167559936.6,
        "start_gps": 1167557888.0,
        "h1": "H-H1_LOSC_4_V1-1167557888-4096.hdf5",
        "l1": "L-L1_LOSC_4_V1-1167557888-4096.hdf5",
    },
    "GW170608": {
        "gps": 1180922494.49,
        "start_gps": 1180920446.0,
        "h1": "H-H1_LOSC_C01_4_V1-1180920446-4096.hdf5",
        "l1": "L-L1_LOSC_C01_4_V1-1180920446-4096.hdf5",
    },
    "GW170823": {
        "gps": 1187529256.5,
        "start_gps": 1187528704.0,
        "h1": "H-H1_GWOSC_O2_4KHZ_R1-1187528704-4096.hdf5",
        "l1": "L-L1_GWOSC_O2_4KHZ_R1-1187528704-4096.hdf5",
    },
    "GW200129_065458": {
        "gps": 1264316116.4,
        "start_gps": 1264314069.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1264314069-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1264314069-4096.hdf5",
    },
    "GW200128_022011": {
        "gps": 1264213229.9,
        "start_gps": 1264211182.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1264211182-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1264211182-4096.hdf5",
    },
    "GW200209_085452": {
        "gps": 1265273710.1,
        "start_gps": 1265271663.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1265271663-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1265271663-4096.hdf5",
    },
    "GW200210_092254": {
        "gps": 1265361792.9,
        "start_gps": 1265359745.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1265359745-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1265359745-4096.hdf5",
    },
    "GW200311_115853": {
        "gps": 1267963151.3,
        "start_gps": 1267961104.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1267961104-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1267961104-4096.hdf5",
    },
    "GW200219_094415": {
        "gps": 1266140673.1,
        "start_gps": 1266138626.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1266138626-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1266138626-4096.hdf5",
    },
    "GW200316_215756": {
        "gps": 1268431094.1,
        "start_gps": 1268429047.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1268429047-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1268429047-4096.hdf5",
    },
    "GW200220_061928": {
        "gps": 1266214786.7,
        "start_gps": 1266212739.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1266212739-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1266212739-4096.hdf5",
    },
}

PHASE_CENTER_RAD = 0.13566981938455774
PHASE_SIGMA_RAD = 0.6
CORE_EVENTS = ("GW170729", "GW170814", "GW170818")
BETA_GRID = np.linspace(-1.5, 1.5, 121)
TAIL_TAU_GRID = (0.025, 0.04, 0.05, 0.06, 0.08)
WINDOWS = ((0.01, 0.45), (0.01, 0.50), (0.01, 0.55), (0.01, 0.60))


def rankdata(values):
    order = np.argsort(values)
    ranks = np.empty(len(values), dtype=np.float64)
    i = 0
    while i < len(values):
        j = i
        while j + 1 < len(values) and values[order[j + 1]] == values[order[i]]:
            j += 1
        rank = 0.5 * (i + j) + 1.0
        ranks[order[i : j + 1]] = rank
        i = j + 1
    return ranks


def spearman_rho(x, y):
    rx = rankdata(np.asarray(x, dtype=np.float64))
    ry = rankdata(np.asarray(y, dtype=np.float64))
    rx -= np.mean(rx)
    ry -= np.mean(ry)
    denom = math.sqrt(float(np.dot(rx, rx) * np.dot(ry, ry)))
    if denom == 0.0:
        return np.nan
    return float(np.dot(rx, ry) / denom)


def empirical_positive_correlation_pvalue(x, y, n_trials, seed):
    obs = spearman_rho(x, y)
    rng = np.random.default_rng(seed)
    ge = 0
    y = np.asarray(y, dtype=np.float64)
    for _ in range(n_trials):
        rho = spearman_rho(x, y[rng.permutation(len(y))])
        if rho >= obs:
            ge += 1
    return obs, (ge + 1.0) / (n_trials + 1.0)


def wrap_phase_pi(x):
    return 0.5 * math.atan2(math.sin(2.0 * x), math.cos(2.0 * x))


def read_strain(path):
    with h5py.File(path, "r") as handle:
        strain = np.asarray(handle["strain"]["Strain"], dtype=np.float64)
        duration = float(np.asarray(handle["meta"]["Duration"]))
    fs = len(strain) / duration
    finite = np.isfinite(strain)
    if not finite.all():
        idx = np.arange(len(strain))
        strain = strain.copy()
        strain[~finite] = np.interp(idx[~finite], idx[finite], strain[finite])
    return strain, fs


def bandpass(x, fs):
    sos = signal.butter(4, [5.0, 80.0], btype="bandpass", fs=fs, output="sos")
    return signal.sosfiltfilt(sos, x)


def shift_zero(x, shift):
    out = np.zeros_like(x)
    if shift > 0:
        out[:-shift] = x[shift:]
    elif shift < 0:
        out[-shift:] = x[:shift]
    else:
        out[:] = x
    return out


def locate_merger(h1, fs, gps, start_gps):
    guess_idx = int(round((gps - start_gps) * fs))
    half = int(round(0.2 * fs))
    lo = max(0, guess_idx - half)
    hi = min(len(h1), guess_idx + half)
    return lo + int(np.argmax(np.abs(h1[lo:hi])))


def align(h1, l1, merger_idx, fs):
    max_shift = int(round(0.010 * fs))
    half = int(round(0.100 * fs))
    lo = max(0, merger_idx - half)
    hi = min(len(h1), merger_idx + half)
    ref = h1[lo:hi] - np.mean(h1[lo:hi])
    ref_norm = np.linalg.norm(ref)
    if ref_norm == 0.0:
        return l1, 0
    ref = ref / ref_norm
    best_shift = 0
    best_score = -np.inf
    for shift in range(-max_shift, max_shift + 1):
        trial = shift_zero(l1, shift)
        seg = trial[lo:hi] - np.mean(trial[lo:hi])
        seg_norm = np.linalg.norm(seg)
        if seg_norm == 0.0:
            continue
        score = abs(np.dot(ref, seg / seg_norm))
        if score > best_score:
            best_score = score
            best_shift = shift
    return shift_zero(l1, best_shift), best_shift


def estimate_psd(x, fs):
    nperseg = min(8192, len(x))
    freq, psd = signal.welch(
        x,
        fs=fs,
        window="hann",
        nperseg=nperseg,
        noverlap=nperseg // 2,
        detrend="constant",
        scaling="density",
    )
    return freq, np.maximum(psd, 1e-30)


def whiten(x, fs, psd_freq, psd_val):
    x = signal.detrend(np.asarray(x, dtype=np.float64), type="constant")
    window = signal.windows.tukey(len(x), alpha=0.25)
    spec = np.fft.rfft(x * window)
    freq = np.fft.rfftfreq(len(x), d=1.0 / fs)
    psd_i = np.interp(freq, psd_freq, psd_val)
    return np.fft.irfft(spec / np.sqrt(psd_i), n=len(x))


def tail_column(n, fs, tau):
    t = np.arange(n, dtype=np.float64) / fs
    return np.exp(-t / tau)


def build_tail_cache(fs, psd_h1, seg_len):
    cache = {}
    for tail_tau in TAIL_TAU_GRID:
        tail = tail_column(seg_len, fs, tail_tau)
        tail_w = whiten(tail, fs, *psd_h1)
        norm = np.linalg.norm(tail_w)
        if norm == 0.0:
            continue
        cache[tail_tau] = tail_w / norm
    return cache


def scan_residual(h1_seg, l1_seg, fs, psd_h1, tail_cache):
    h1_w = whiten(h1_seg, fs, *psd_h1)
    l1_w = whiten(l1_seg, fs, *psd_h1)
    best = None
    for beta in BETA_GRID:
        y = h1_w - beta * l1_w
        for tail_tau, tail_w in tail_cache.items():
            amp = float(np.dot(y, tail_w))
            delta = amp * amp
            row = {
                "delta": delta,
                "beta": float(beta),
                "tail_tau_s": float(tail_tau),
                "amp": amp,
            }
            if best is None or row["delta"] > best["delta"]:
                best = row
    return best


def complex_impulse(seg, fs):
    dt = 1.0 / fs
    analytic = signal.hilbert(seg)
    d2 = np.gradient(np.gradient(analytic, dt), dt)
    phase_anchor = analytic / np.maximum(np.abs(analytic), 1e-30)
    return complex(np.trapezoid(d2 * np.conj(phase_anchor), dx=dt))


def morphology_proxy(residual, fs):
    dt = 1.0 / fs
    env = np.abs(signal.hilbert(residual))
    env_rms = math.sqrt(float(np.mean(env * env)))
    if env_rms == 0.0:
        return 0.0
    env = env / env_rms
    d2 = np.gradient(np.gradient(env, dt), dt)

    window = signal.windows.tukey(len(residual), alpha=0.25)
    spec = np.fft.rfft(residual * window)
    freq = np.fft.rfftfreq(len(residual), d=dt)
    power = np.abs(spec) ** 2
    total_power = float(np.sum(power))
    if total_power == 0.0:
        return 0.0
    centroid = float(np.sum(freq * power) / total_power)
    spread = math.sqrt(float(np.sum(((freq - centroid) ** 2) * power) / total_power))
    roughness = float(np.trapezoid(np.abs(d2), dx=dt))
    amp = float(np.mean(residual * residual))
    return amp * spread * roughness


def prepare_event(base_dir, event_name):
    cfg = EVENTS[event_name]
    h1, fs1 = read_strain(base_dir / cfg["h1"])
    l1, fs2 = read_strain(base_dir / cfg["l1"])
    if not np.isclose(fs1, fs2):
        raise ValueError(f"Sampling mismatch for {event_name}")
    fs = fs1
    h1 = bandpass(h1, fs)
    l1 = bandpass(l1, fs)
    merger_idx = locate_merger(h1, fs, cfg["gps"], cfg["start_gps"])
    l1, shift = align(h1, l1, merger_idx, fs)
    return {
        "event": event_name,
        "fs": fs,
        "merger_idx": merger_idx,
        "h1": h1,
        "l1": l1,
        "shift_ms": 1000.0 * shift / fs,
        "psd_h1": estimate_psd(h1, fs),
    }


def best_on_source_row(prepped):
    best = None
    for start_after, end_after in WINDOWS:
        fs = prepped["fs"]
        start_idx = prepped["merger_idx"] + int(round(start_after * fs))
        seg_len = int(round((end_after - start_after) * fs))
        end_idx = start_idx + seg_len
        tail_cache = build_tail_cache(fs, prepped["psd_h1"], seg_len)
        row = scan_residual(
            prepped["h1"][start_idx:end_idx],
            prepped["l1"][start_idx:end_idx],
            fs,
            prepped["psd_h1"],
            tail_cache,
        )
        row["start_after"] = start_after
        row["end_after"] = end_after
        if best is None or row["delta"] > best["delta"]:
            best = row
    return best


def event_row(base_dir, event_name):
    prepped = prepare_event(base_dir, event_name)
    row = best_on_source_row(prepped)

    fs = prepped["fs"]
    start_idx = prepped["merger_idx"] + int(round(row["start_after"] * fs))
    end_idx = prepped["merger_idx"] + int(round(row["end_after"] * fs))
    h1_seg = prepped["h1"][start_idx:end_idx]
    l1_seg = prepped["l1"][start_idx:end_idx]

    q_h1 = complex_impulse(h1_seg, fs)
    q_l1 = complex_impulse(l1_seg, fs)
    q_h1_phase = math.atan2(q_h1.imag, q_h1.real)
    q_l1_phase = math.atan2(q_l1.imag, q_l1.real)
    dphi_pi = wrap_phase_pi((q_h1_phase - row["beta"] * q_l1_phase) - PHASE_CENTER_RAD)
    phase_gate = math.exp(-(dphi_pi * dphi_pi) / (2.0 * PHASE_SIGMA_RAD * PHASE_SIGMA_RAD))
    coherent = ((abs(q_h1) ** 2) + (abs(row["beta"]) ** 2) * (abs(q_l1) ** 2)) * phase_gate

    h1_w = whiten(h1_seg, fs, *prepped["psd_h1"])
    l1_w = whiten(l1_seg, fs, *prepped["psd_h1"])
    residual = h1_w - row["beta"] * l1_w
    morph = morphology_proxy(residual, fs)
    return {
        "event": event_name,
        "delta": row["delta"],
        "beta": row["beta"],
        "coherent_predictor": coherent,
        "morph_predictor": morph,
        "dphi_pi": dphi_pi,
    }


def calibrate_lambda(rows, core_events):
    core = [row for row in rows if row["event"] in core_events]
    coherent_scale = float(np.median([row["coherent_predictor"] for row in core]))
    morph_scale = float(np.median([row["morph_predictor"] for row in core]))
    if morph_scale <= 0.0:
        return 1.0, coherent_scale, morph_scale
    return coherent_scale / morph_scale, coherent_scale, morph_scale


def main():
    parser = argparse.ArgumentParser(
        description="Independent replication of the frozen UTG two-channel source-law test."
    )
    parser.add_argument("--data-dir", default=".")
    parser.add_argument(
        "--events",
        nargs="*",
        default=[
            "GW150914",
            "GW151226",
            "GW170104",
            "GW170608",
            "GW170823",
            "GW200129_065458",
            "GW200128_022011",
            "GW200209_085452",
            "GW200210_092254",
            "GW200311_115853",
            "GW200219_094415",
            "GW200316_215756",
            "GW200220_061928",
        ],
    )
    parser.add_argument(
        "--calibration-events",
        nargs="*",
        default=list(CORE_EVENTS),
    )
    parser.add_argument("--n-trials", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=12345)
    args = parser.parse_args()

    base_dir = Path(args.data_dir)
    names = list(dict.fromkeys(args.calibration_events + args.events))
    rows = [event_row(base_dir, e) for e in names]
    by_event = {row["event"]: row for row in rows}
    lam, coherent_scale, morph_scale = calibrate_lambda(rows, args.calibration_events)
    eval_rows = [by_event[e] for e in args.events]
    for row in eval_rows:
        row["predictor_two_channel"] = row["coherent_predictor"] + lam * row["morph_predictor"]

    deltas = np.array([row["delta"] for row in eval_rows], dtype=np.float64)
    predictors = np.array([row["predictor_two_channel"] for row in eval_rows], dtype=np.float64)
    rho, p = empirical_positive_correlation_pvalue(predictors, deltas, args.n_trials, args.seed)

    print("Independent replication of frozen UTG two-channel source law:")
    print("Delta_UTG ~ coherent_channel + lambda_core * morphology_channel")
    print("coherent_channel = (|Q_H1|^2 + |beta|^2 |Q_L1|^2) * C_phi_pi")
    print("morphology_channel = residual_rms^2 * spectral_spread * envelope_roughness")
    print(f"phi_*= {PHASE_CENTER_RAD:.6f} sigma_phi={PHASE_SIGMA_RAD:.6f}")
    print(f"lambda_core={lam:.6e}")
    print(f"core_coherent_median={coherent_scale:.6e}")
    print(f"core_morph_median={morph_scale:.6e}")
    print()
    print("Event ranking by observed cross-residual delta:")
    for row in sorted(eval_rows, key=lambda item: item["delta"], reverse=True):
        print(
            f"{row['event']}: delta={row['delta']:.6e} two_channel={row['predictor_two_channel']:.6e} "
            f"coh={row['coherent_predictor']:.6e} morph={row['morph_predictor']:.6e} "
            f"beta={row['beta']:.3f} dphi_pi={row['dphi_pi']:.3f}"
        )
    print()
    print("Event ranking by two-channel predictor:")
    for row in sorted(eval_rows, key=lambda item: item["predictor_two_channel"], reverse=True):
        print(f"{row['event']}: two_channel={row['predictor_two_channel']:.6e} delta={row['delta']:.6e}")
    print()
    print(f"spearman_rho={rho:.6e}")
    print(f"empirical_positive_correlation_p={p:.6e}")


if __name__ == "__main__":
    main()
