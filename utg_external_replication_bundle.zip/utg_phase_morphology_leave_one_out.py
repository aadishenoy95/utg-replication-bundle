import argparse
from pathlib import Path

import numpy as np

import utg_phase_morphology_law_test as pm
import utg_cross_residual_two_channel_scaling_test as twoch


def main():
    parser = argparse.ArgumentParser(
        description="Leave-one-out robustness check for the UTG phase-morphology law."
    )
    parser.add_argument("--data-dir", default=".")
    parser.add_argument(
        "--events",
        nargs="*",
        default=[
            "GW150914",
            "GW151226",
            "GW170104",
            "GW170608",
            "GW170823",
            "GW200129_065458",
            "GW200128_022011",
            "GW200209_085452",
            "GW200210_092254",
            "GW200311_115853",
            "GW200219_094415",
            "GW200316_215756",
            "GW200220_061928",
        ],
    )
    parser.add_argument(
        "--calibration-events",
        nargs="*",
        default=list(twoch.CORE_EVENTS),
    )
    parser.add_argument("--n-trials", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=12345)
    args = parser.parse_args()

    base_dir = Path(args.data_dir)
    calib_rows = [twoch.event_row(base_dir, e) for e in list(dict.fromkeys(args.calibration_events + args.events))]
    lambda_core, coherent_scale, morph_scale = twoch.calibrate_lambda(calib_rows, args.calibration_events)
    rows = [pm.event_row(base_dir, e, lambda_core) for e in args.events]

    x = np.array([row["morph_frac"] for row in rows], dtype=np.float64)
    y = np.array([row["abs_dphi_pi"] for row in rows], dtype=np.float64)
    full_rho, full_p = pm.empirical_positive_correlation_pvalue(x, y, args.n_trials, args.seed)

    print("UTG phase-morphology leave-one-out robustness:")
    print(f"lambda_core={lambda_core:.6e}")
    print(f"core_coherent_median={coherent_scale:.6e}")
    print(f"core_morph_median={morph_scale:.6e}")
    print()
    print(f"full_set_rho={full_rho:.6e}")
    print(f"full_set_p={full_p:.6e}")
    print()

    loo_rows = []
    for i, dropped in enumerate(args.events):
        rho, p = pm.empirical_positive_correlation_pvalue(
            np.delete(x, i), np.delete(y, i), args.n_trials, args.seed
        )
        loo_rows.append({"dropped": dropped, "rho": rho, "p": p})

    print("Leave-one-out results:")
    for row in sorted(loo_rows, key=lambda item: item["p"]):
        print(f"drop={row['dropped']}: rho={row['rho']:.6e} p={row['p']:.6e}")

    ps = np.array([row["p"] for row in loo_rows], dtype=np.float64)
    rhos = np.array([row["rho"] for row in loo_rows], dtype=np.float64)
    print()
    print(f"loo_best_p={np.min(ps):.6e}")
    print(f"loo_worst_p={np.max(ps):.6e}")
    print(f"loo_median_p={np.median(ps):.6e}")
    print(f"loo_best_rho={np.max(rhos):.6e}")
    print(f"loo_worst_rho={np.min(rhos):.6e}")
    print(f"loo_median_rho={np.median(rhos):.6e}")


if __name__ == "__main__":
    main()
