# UTG External Replication Master Protocol

This bundle is the frozen outside-facing replication pack for the current UTG
program in this workspace.

## What This Bundle Contains

The bundle freezes four UTG laws:

1. Two-channel source law
2. Phase-morphology law
3. Phase-strength law
4. Quantum interference law

The first law is the strongest source-law result.
The fourth law is the strongest quantum-sector result.

## Environment

Use a clean Python environment with:

- `numpy`
- `scipy`
- `h5py`

Install with:

```powershell
python -m pip install -r requirements.txt
```

## Data

This bundle assumes the same GWOSC H1/L1 `.hdf5` files are present in one local
data folder. The runner does not download data.

When running from the bundle, pass the absolute path to that folder through the
`-DataDir` argument.

## One-Command Run

```powershell
.\RUN_ALL_UTG_LAWS.ps1 -DataDir "C:\path\to\gwosc\data" -PythonExe python
```

## One-Command Bootstrap Run

This is the simplest outside-machine path. It creates a clean venv, installs the
requirements, verifies the frozen file hashes, and runs all four laws:

```powershell
.\BOOTSTRAP_AND_RUN.ps1 -DataDir "C:\path\to\gwosc\data" -PythonCmd python
```

## Expected Headline Outputs

### Law 1: Two-Channel Source Law

- `spearman_rho = 8.736264e-01`
- `empirical_positive_correlation_p = 1.499925e-04`

### Law 2: Phase-Morphology Law

- `spearman_rho = 6.648352e-01`
- `empirical_positive_correlation_p = 9.599520e-03`

### Law 3: Phase-Strength Law

- `spearman_rho = -5.172932e-01`
- `empirical_negative_correlation_p = 1.049948e-02`

### Law 4: Quantum Interference Law

- `spearman_rho = -8.956044e-01`
- `empirical_negative_correlation_p = 4.999750e-05`

## Included Protocol Notes

- `UTG_MASTER_SUMMARY.md`
- `UTG_TWO_CHANNEL_EXTERNAL_REPLICATION_PROTOCOL.md`
- `UTG_PHASE_MORPHOLOGY_LAW_PROTOCOL.md`
- `UTG_PHASE_STRENGTH_LAW_PROTOCOL.md`
- `UTG_QUANTUM_INTERFERENCE_LAW_PROTOCOL.md`

## Claim Boundary

Matching these outputs means the bundle reproduced the current frozen UTG
results from this workspace.

That is replication of the bundle.

It is strongest when done:

- on a separate machine or VM
- in a clean environment
- without changing any files
