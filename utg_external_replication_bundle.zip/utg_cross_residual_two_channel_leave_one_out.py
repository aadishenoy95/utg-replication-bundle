import argparse
from pathlib import Path

import numpy as np

import utg_cross_residual_two_channel_scaling_test as twoch


def main():
    parser = argparse.ArgumentParser(
        description="Leave-one-out robustness check for the frozen UTG two-channel source law."
    )
    parser.add_argument("--data-dir", default=".")
    parser.add_argument(
        "--events",
        nargs="*",
        default=[
            "GW150914",
            "GW151226",
            "GW170104",
            "GW170608",
            "GW170823",
            "GW200129_065458",
            "GW200128_022011",
            "GW200209_085452",
            "GW200210_092254",
            "GW200311_115853",
            "GW200219_094415",
            "GW200316_215756",
            "GW200220_061928",
        ],
    )
    parser.add_argument(
        "--calibration-events",
        nargs="*",
        default=list(twoch.CORE_EVENTS),
    )
    parser.add_argument("--n-trials", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=12345)
    args = parser.parse_args()

    base_dir = Path(args.data_dir)
    calibration_names = list(dict.fromkeys(args.calibration_events))
    event_names = list(dict.fromkeys(calibration_names + args.events))
    rows = [twoch.event_row(base_dir, e) for e in event_names]
    by_event = {row["event"]: row for row in rows}
    lam, coherent_scale, morph_scale = twoch.calibrate_lambda(rows, calibration_names)

    eval_rows = []
    for name in args.events:
        row = dict(by_event[name])
        row["predictor_two_channel"] = row["coherent_predictor"] + lam * row["morph_predictor"]
        eval_rows.append(row)

    print("Frozen UTG two-channel leave-one-out robustness:")
    print(f"lambda_core={lam:.6e}")
    print(f"core_coherent_median={coherent_scale:.6e}")
    print(f"core_morph_median={morph_scale:.6e}")
    print()

    all_predictors = np.array([row["predictor_two_channel"] for row in eval_rows], dtype=np.float64)
    all_deltas = np.array([row["delta"] for row in eval_rows], dtype=np.float64)
    full_rho, full_p = twoch.empirical_positive_correlation_pvalue(
        all_predictors, all_deltas, args.n_trials, args.seed
    )
    print(f"full_set_rho={full_rho:.6e}")
    print(f"full_set_p={full_p:.6e}")
    print()

    loo_rows = []
    for i, dropped in enumerate(args.events):
        keep_predictors = np.delete(all_predictors, i)
        keep_deltas = np.delete(all_deltas, i)
        rho, p = twoch.empirical_positive_correlation_pvalue(
            keep_predictors, keep_deltas, args.n_trials, args.seed
        )
        loo_rows.append({"dropped": dropped, "rho": rho, "p": p})

    print("Leave-one-out results:")
    for row in sorted(loo_rows, key=lambda item: item["p"]):
        print(f"drop={row['dropped']}: rho={row['rho']:.6e} p={row['p']:.6e}")

    ps = np.array([row["p"] for row in loo_rows], dtype=np.float64)
    rhos = np.array([row["rho"] for row in loo_rows], dtype=np.float64)
    print()
    print(f"loo_best_p={np.min(ps):.6e}")
    print(f"loo_worst_p={np.max(ps):.6e}")
    print(f"loo_median_p={np.median(ps):.6e}")
    print(f"loo_best_rho={np.max(rhos):.6e}")
    print(f"loo_worst_rho={np.min(rhos):.6e}")
    print(f"loo_median_rho={np.median(rhos):.6e}")


if __name__ == "__main__":
    main()
