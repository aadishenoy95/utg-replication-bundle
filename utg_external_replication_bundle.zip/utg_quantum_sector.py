"""Quantum-sector utilities for UTG.

This module turns the frozen two-channel source-law decomposition into a
normalized two-state sector:

    |Psi_UTG> = sqrt(p_C) |C> + exp(i * Delta_phi_pi) sqrt(p_M) |M>

where p_C and p_M are the coherent and morphology weights derived from the
frozen two-channel source law.
"""

from __future__ import annotations

import math
from typing import Any, Dict, Tuple

import numpy as np


EPS = 1e-300


def normalize_weights(coherent: float, morph: float) -> Tuple[float, float, float]:
    """Return normalized coherent/morphology weights and their total."""

    coherent = float(coherent)
    morph = float(morph)
    total = coherent + morph
    if not math.isfinite(total) or total <= 0.0:
        return 0.5, 0.5, 0.0
    return coherent / total, morph / total, total


def mixing_angle(p_coherent: float, p_morph: float) -> float:
    """Sector angle on the two-state Bloch-like decomposition."""

    return math.atan2(math.sqrt(max(p_morph, 0.0)), math.sqrt(max(p_coherent, 0.0)))


def sector_entropy(p_coherent: float, p_morph: float) -> float:
    """Binary entropy of the sector weights in nats."""

    entropy = 0.0
    for p in (p_coherent, p_morph):
        if p > 0.0:
            entropy -= p * math.log(p)
    return entropy


def interference_term(p_coherent: float, p_morph: float, phase: float) -> float:
    """Quantum-style interference observable."""

    return 2.0 * math.sqrt(max(p_coherent, 0.0) * max(p_morph, 0.0)) * math.cos(phase)


def state_vector(p_coherent: float, p_morph: float, phase: float) -> np.ndarray:
    """Complex two-component sector state."""

    return np.array(
        [
            math.sqrt(max(p_coherent, 0.0)),
            np.exp(1j * phase) * math.sqrt(max(p_morph, 0.0)),
        ],
        dtype=np.complex128,
    )


def build_sector_row(two_channel_row: Dict[str, Any], tail_row: Dict[str, Any], lambda_core: float) -> Dict[str, Any]:
    """Merge the frozen two-channel row with the cross-residual tail row."""

    coherent = float(two_channel_row["coherent_predictor"])
    morph = float(lambda_core) * float(two_channel_row["morph_predictor"])
    p_coherent, p_morph, total = normalize_weights(coherent, morph)
    phase = float(two_channel_row["dphi_pi"])
    theta = mixing_angle(p_coherent, p_morph)
    entropy = sector_entropy(p_coherent, p_morph)
    interference = interference_term(p_coherent, p_morph, phase)
    psi = state_vector(p_coherent, p_morph, phase)
    sector = "coherent" if p_coherent >= p_morph else "morphology"

    return {
        "event": two_channel_row["event"],
        "delta": float(tail_row["delta"]),
        "beta": float(tail_row["beta"]),
        "tail_tau_s": float(tail_row["tail_tau_s"]),
        "coherent": coherent,
        "morph": morph,
        "total": total,
        "p_coherent": p_coherent,
        "p_morph": p_morph,
        "sector_angle_rad": theta,
        "sector_entropy_nats": entropy,
        "interference": interference,
        "sector": sector,
        "dphi_pi": phase,
        "psi": psi,
    }
