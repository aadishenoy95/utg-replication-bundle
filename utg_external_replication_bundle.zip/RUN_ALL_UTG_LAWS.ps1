param(
    [Parameter(Mandatory = $true)]
    [string]$DataDir,
    [string]$PythonExe = "python"
)

$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Here

$law1Events = @(
    "GW150914","GW151226","GW170104","GW170608","GW170823",
    "GW200129_065458","GW200128_022011","GW200209_085452",
    "GW200210_092254","GW200311_115853","GW200219_094415",
    "GW200316_215756","GW200220_061928"
)

$law3Events = @(
    "GW150914","GW151226","GW170104","GW170608","GW170823",
    "GW200129_065458","GW200128_022011","GW200209_085452",
    "GW200210_092254","GW200311_115853","GW200219_094415",
    "GW200316_215756","GW200220_061928","GW191109_010717",
    "GW191127_050227","GW200208_130117","GW200216_220804",
    "GW200220_124850","GW200224_222234","GW200225_060421"
)

Write-Host "Running Law 1: two-channel source law"
& $PythonExe ".\utg_cross_residual_two_channel_scaling_test.py" --data-dir $DataDir --events $law1Events --n-trials 20000
Write-Host ""

Write-Host "Running Law 2: phase-morphology law"
& $PythonExe ".\utg_phase_morphology_law_test.py" --data-dir $DataDir --events $law1Events --n-trials 20000
Write-Host ""

Write-Host "Running Law 3: phase-strength law"
& $PythonExe ".\utg_phase_strength_law_test.py" --data-dir $DataDir --events $law3Events --n-trials 20000
Write-Host ""

Write-Host "Running Law 4: quantum interference law"
& $PythonExe ".\utg_quantum_interference_law_test.py" --data-dir $DataDir --events $law1Events --n-trials 20000
