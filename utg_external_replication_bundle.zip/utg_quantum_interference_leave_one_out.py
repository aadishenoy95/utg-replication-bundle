import argparse
from pathlib import Path

import numpy as np

import utg_cross_residual_two_channel_scaling_test as twoch
import utg_quantum_interference_law_test as qlaw


def main():
    parser = argparse.ArgumentParser(
        description="Leave-one-out robustness check for the UTG quantum interference law."
    )
    parser.add_argument("--data-dir", default=".")
    parser.add_argument("--events", nargs="*", default=qlaw.DEFAULT_EVENTS)
    parser.add_argument("--calibration-events", nargs="*", default=list(twoch.CORE_EVENTS))
    parser.add_argument("--n-trials", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=12345)
    args = parser.parse_args()

    base_dir = Path(args.data_dir)
    calibration = list(dict.fromkeys(args.calibration_events))
    calib_rows = [twoch.event_row(base_dir, e) for e in list(dict.fromkeys(calibration + list(args.events)))]
    lambda_core, coherent_scale, morph_scale = twoch.calibrate_lambda(calib_rows, calibration)
    rows = [qlaw.event_row(base_dir, e, lambda_core) for e in args.events]

    x = np.array([row["interference"] for row in rows], dtype=np.float64)
    y = np.array([row["abs_dphi_pi"] for row in rows], dtype=np.float64)
    full_rho, full_p = qlaw.empirical_negative_correlation_pvalue(x, y, args.n_trials, args.seed)

    print("UTG quantum interference leave-one-out robustness:")
    print(f"lambda_core={lambda_core:.6e}")
    print(f"core_coherent_median={coherent_scale:.6e}")
    print(f"core_morph_median={morph_scale:.6e}")
    print()
    print(f"full_set_rho={full_rho:.6e}")
    print(f"full_set_p={full_p:.6e}")
    print()

    loo_rows = []
    for i, dropped in enumerate(args.events):
        rho, p = qlaw.empirical_negative_correlation_pvalue(
            np.delete(x, i), np.delete(y, i), args.n_trials, args.seed
        )
        loo_rows.append({"dropped": dropped, "rho": rho, "p": p})

    print("Leave-one-out results:")
    for row in sorted(loo_rows, key=lambda item: item["p"]):
        print(f"drop={row['dropped']}: rho={row['rho']:.6e} p={row['p']:.6e}")

    ps = np.array([row["p"] for row in loo_rows], dtype=np.float64)
    rhos = np.array([row["rho"] for row in loo_rows], dtype=np.float64)
    print()
    print(f"loo_best_p={np.min(ps):.6e}")
    print(f"loo_worst_p={np.max(ps):.6e}")
    print(f"loo_median_p={np.median(ps):.6e}")
    print(f"loo_best_rho={np.min(rhos):.6e}")
    print(f"loo_worst_rho={np.max(rhos):.6e}")
    print(f"loo_median_rho={np.median(rhos):.6e}")


if __name__ == "__main__":
    main()
