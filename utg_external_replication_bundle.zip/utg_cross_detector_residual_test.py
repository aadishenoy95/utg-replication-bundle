import argparse
import math
from pathlib import Path

import h5py
import numpy as np
from scipy import signal
from scipy.stats import chi2


EVENTS = {
    "GW150914": {
        "gps": 1126259462.422,
        "start_gps": 1126256640.0,
        "h1": "H-H1_LOSC_4_V1-1126256640-4096.hdf5",
        "l1": "L-L1_LOSC_4_V1-1126256640-4096.hdf5",
    },
    "GW151226": {
        "gps": 1135136350.648,
        "start_gps": 1135136228.0,
        "h1": "H-H1_LOSC_4_V2-1135136228-4096.hdf5",
        "l1": "L-L1_LOSC_4_V2-1135136228-4096.hdf5",
    },
    "GW170104": {
        "gps": 1167559936.6,
        "start_gps": 1167557888.0,
        "h1": "H-H1_LOSC_4_V1-1167557888-4096.hdf5",
        "l1": "L-L1_LOSC_4_V1-1167557888-4096.hdf5",
    },
    "GW170608": {
        "gps": 1180922494.49,
        "start_gps": 1180920446.0,
        "h1": "H-H1_LOSC_C01_4_V1-1180920446-4096.hdf5",
        "l1": "L-L1_LOSC_C01_4_V1-1180920446-4096.hdf5",
    },
    "GW170729": {
        "gps": 1185389807.3,
        "start_gps": 1185386496.0,
        "h1": "H-H1_GWOSC_O2_4KHZ_R1-1185386496-4096.hdf5",
        "l1": "L-L1_GWOSC_O2_4KHZ_R1-1185386496-4096.hdf5",
    },
    "GW170809": {
        "gps": 1186302519.8,
        "start_gps": 1186300472.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1186300472-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1186300472-4096.hdf5",
    },
    "GW170814": {
        "gps": 1186741861.5,
        "start_gps": 1186739813.0,
        "h1": "H-H1_LOSC_C00_4_V1-1186739813-4096.hdf5",
        "l1": "L-L1_LOSC_C00_4_V1-1186739813-4096.hdf5",
    },
    "GW170818": {
        "gps": 1187058327.1,
        "start_gps": 1187057664.0,
        "h1": "H-H1_GWOSC_O2_4KHZ_R1-1187057664-4096.hdf5",
        "l1": "L-L1_GWOSC_O2_4KHZ_R1-1187057664-4096.hdf5",
    },
    "GW200216_220804": {
        "gps": 1265926102.8,
        "start_gps": 1265924055.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1265924055-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1265924055-4096.hdf5",
    },
    "GW200220_124850": {
        "gps": 1266238148.1,
        "start_gps": 1266236101.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1266236101-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1266236101-4096.hdf5",
    },
    "GW200220_061928": {
        "gps": 1266214786.7,
        "start_gps": 1266212739.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1266212739-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1266212739-4096.hdf5",
    },
    "GW200225_060421": {
        "gps": 1266645879.3,
        "start_gps": 1266643832.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1266643832-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1266643832-4096.hdf5",
    },
    "GW200129_065458": {
        "gps": 1264316116.4,
        "start_gps": 1264314069.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1264314069-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1264314069-4096.hdf5",
    },
    "GW200128_022011": {
        "gps": 1264213229.9,
        "start_gps": 1264211182.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1264211182-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1264211182-4096.hdf5",
    },
    "GW200209_085452": {
        "gps": 1265273710.1,
        "start_gps": 1265271663.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1265271663-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1265271663-4096.hdf5",
    },
    "GW200210_092254": {
        "gps": 1265361792.9,
        "start_gps": 1265359745.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1265359745-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1265359745-4096.hdf5",
    },
    "GW200219_094415": {
        "gps": 1266140673.1,
        "start_gps": 1266138626.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1266138626-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1266138626-4096.hdf5",
    },
    "GW200311_115853": {
        "gps": 1267963151.3,
        "start_gps": 1267961104.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1267961104-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1267961104-4096.hdf5",
    },
    "GW200316_215756": {
        "gps": 1268431094.1,
        "start_gps": 1268429047.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1268429047-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1268429047-4096.hdf5",
    },
    "GW191109_010717": {
        "gps": 1257296834.1,
        "start_gps": 1257294808.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1257294808-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1257294808-4096.hdf5",
    },
    "GW191127_050227": {
        "gps": 1258866617.2,
        "start_gps": 1258864118.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1258864118-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1258864118-4096.hdf5",
    },
    "GW170823": {
        "gps": 1187529256.5,
        "start_gps": 1187528704.0,
        "h1": "H-H1_GWOSC_O2_4KHZ_R1-1187528704-4096.hdf5",
        "l1": "L-L1_GWOSC_O2_4KHZ_R1-1187528704-4096.hdf5",
    },
    "GW190519_153544": {
        "gps": 1242315353.7,
        "start_gps": 1242313315.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1242313315-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1242313315-4096.hdf5",
    },
    "GW190521": {
        "gps": 1242442967.4,
        "start_gps": 1242440920.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1242440920-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1242440920-4096.hdf5",
    },
    "GW190929_012149": {
        "gps": 1253756508.0,
        "start_gps": 1253753280.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1253753280-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1253753280-4096.hdf5",
    },
    "GW190701_203306": {
        "gps": 1246049574.9,
        "start_gps": 1246046357.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1246046357-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1246046357-4096.hdf5",
    },
    "GW200224_222234": {
        "gps": 1266618172.4,
        "start_gps": 1266616125.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1266616125-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1266616125-4096.hdf5",
    },
    "GW200208_130117": {
        "gps": 1265200887.3,
        "start_gps": 1265200048.0,
        "h1": "H-H1_GWOSC_4KHZ_R1-1265200048-4096.hdf5",
        "l1": "L-L1_GWOSC_4KHZ_R1-1265200048-4096.hdf5",
    },
}

BETA_GRID = np.linspace(-1.5, 1.5, 121)
TAIL_TAU_GRID = (0.025, 0.04, 0.05, 0.06, 0.08)
WINDOWS = ((0.01, 0.45), (0.01, 0.50), (0.01, 0.55), (0.01, 0.60))


def read_strain(path):
    with h5py.File(path, "r") as handle:
        strain = np.asarray(handle["strain"]["Strain"], dtype=np.float64)
        duration = float(np.asarray(handle["meta"]["Duration"]))
    fs = len(strain) / duration
    finite = np.isfinite(strain)
    if not finite.all():
        idx = np.arange(len(strain))
        strain = strain.copy()
        strain[~finite] = np.interp(idx[~finite], idx[finite], strain[finite])
    return strain, fs


def bandpass(x, fs):
    sos = signal.butter(4, [5.0, 80.0], btype="bandpass", fs=fs, output="sos")
    return signal.sosfiltfilt(sos, x)


def shift_zero(x, shift):
    out = np.zeros_like(x)
    if shift > 0:
        out[:-shift] = x[shift:]
    elif shift < 0:
        out[-shift:] = x[:shift]
    else:
        out[:] = x
    return out


def locate_merger(h1, fs, gps, start_gps):
    guess_idx = int(round((gps - start_gps) * fs))
    half = int(round(0.2 * fs))
    lo = max(0, guess_idx - half)
    hi = min(len(h1), guess_idx + half)
    return lo + int(np.argmax(np.abs(h1[lo:hi])))


def align(h1, l1, merger_idx, fs):
    max_shift = int(round(0.010 * fs))
    half = int(round(0.100 * fs))
    lo = max(0, merger_idx - half)
    hi = min(len(h1), merger_idx + half)
    ref = h1[lo:hi] - np.mean(h1[lo:hi])
    ref /= np.linalg.norm(ref)

    best_shift = 0
    best_score = -np.inf
    for shift in range(-max_shift, max_shift + 1):
        trial = shift_zero(l1, shift)
        seg = trial[lo:hi] - np.mean(trial[lo:hi])
        norm = np.linalg.norm(seg)
        if norm == 0:
            continue
        score = abs(np.dot(ref, seg / norm))
        if score > best_score:
            best_score = score
            best_shift = shift
    return shift_zero(l1, best_shift), best_shift


def estimate_psd(x, fs):
    nperseg = min(8192, len(x))
    freq, psd = signal.welch(
        x,
        fs=fs,
        window="hann",
        nperseg=nperseg,
        noverlap=nperseg // 2,
        detrend="constant",
        scaling="density",
    )
    return freq, np.maximum(psd, 1e-30)


def whiten(x, fs, psd_freq, psd_val):
    x = signal.detrend(np.asarray(x, dtype=np.float64), type="constant")
    window = signal.windows.tukey(len(x), alpha=0.25)
    spec = np.fft.rfft(x * window)
    freq = np.fft.rfftfreq(len(x), d=1.0 / fs)
    psd_i = np.interp(freq, psd_freq, psd_val)
    return np.fft.irfft(spec / np.sqrt(psd_i), n=len(x))


def tail_column(n, fs, tau):
    t = np.arange(n, dtype=np.float64) / fs
    return np.exp(-t / tau)


def build_template_cache(fs, psd_h1, seg_len):
    cache = {}
    for tail_tau in TAIL_TAU_GRID:
        tail = tail_column(seg_len, fs, tail_tau)
        tail_w = whiten(tail, fs, *psd_h1)
        norm = np.linalg.norm(tail_w)
        if norm == 0:
            continue
        cache[tail_tau] = tail_w / norm
    return cache


def valid_background_starts(n, seg_len, merger_idx, fs):
    valid = np.ones(n - seg_len + 1, dtype=bool)
    veto_lo = max(0, merger_idx - int(round(1.5 * fs)))
    veto_hi = min(n, merger_idx + int(round(1.5 * fs)))
    start_lo = max(0, veto_lo - seg_len + 1)
    start_hi = min(len(valid), veto_hi)
    valid[start_lo:start_hi] = False
    return np.flatnonzero(valid)


def prepare_event(base_dir, name, cfg):
    h1, fs1 = read_strain(base_dir / cfg["h1"])
    l1, fs2 = read_strain(base_dir / cfg["l1"])
    if not np.isclose(fs1, fs2):
        raise ValueError(f"Sampling mismatch for {name}")
    fs = fs1
    h1 = bandpass(h1, fs)
    l1 = bandpass(l1, fs)
    merger_idx = locate_merger(h1, fs, cfg["gps"], cfg["start_gps"])
    l1, shift = align(h1, l1, merger_idx, fs)
    return {
        "name": name,
        "fs": fs,
        "merger_idx": merger_idx,
        "shift_ms": 1000.0 * shift / fs,
        "h1": h1,
        "l1": l1,
        "psd_h1": estimate_psd(h1, fs),
    }


def scan_residual(h1_seg, l1_seg, fs, psd_h1, tail_cache):
    h1_w = whiten(h1_seg, fs, *psd_h1)
    l1_w = whiten(l1_seg, fs, *psd_h1)
    best = None
    for beta in BETA_GRID:
        y = h1_w - beta * l1_w
        for tail_tau, tail_w in tail_cache.items():
            amp = float(np.dot(y, tail_w))
            delta = amp * amp
            row = {
                "delta": delta,
                "beta": float(beta),
                "tail_tau_s": float(tail_tau),
                "amp": amp,
            }
            if best is None or row["delta"] > best["delta"]:
                best = row
    return best


def ensure_window_cache(event, start_after, end_after):
    key = (start_after, end_after)
    if "window_cache" not in event:
        event["window_cache"] = {}
    if key in event["window_cache"]:
        return event["window_cache"][key]
    seg_len = int(round((end_after - start_after) * event["fs"]))
    cache = {
        "seg_len": seg_len,
        "tail_cache": build_template_cache(event["fs"], event["psd_h1"], seg_len),
        "valid_starts": valid_background_starts(len(event["h1"]), seg_len, event["merger_idx"], event["fs"]),
    }
    event["window_cache"][key] = cache
    return cache


def on_source_best(event):
    best = None
    for start_after, end_after in WINDOWS:
        fs = event["fs"]
        cache = ensure_window_cache(event, start_after, end_after)
        start_idx = event["merger_idx"] + int(round(start_after * fs))
        end_idx = start_idx + cache["seg_len"]
        row = scan_residual(
            event["h1"][start_idx:end_idx],
            event["l1"][start_idx:end_idx],
            fs,
            event["psd_h1"],
            cache["tail_cache"],
        )
        row["start_after"] = start_after
        row["end_after"] = end_after
        if best is None or row["delta"] > best["delta"]:
            best = row
    return best


def background_trials(events, n_trials, seed):
    rng = np.random.default_rng(seed)
    totals = np.empty(n_trials, dtype=np.float64)
    for i in range(n_trials):
        total = 0.0
        for event in events:
            fs = event["fs"]
            best = None
            for start_after, end_after in WINDOWS:
                cache = ensure_window_cache(event, start_after, end_after)
                start_idx = int(rng.choice(cache["valid_starts"]))
                end_idx = start_idx + cache["seg_len"]
                row = scan_residual(
                    event["h1"][start_idx:end_idx],
                    event["l1"][start_idx:end_idx],
                    fs,
                    event["psd_h1"],
                    cache["tail_cache"],
                )
                if best is None or row["delta"] > best["delta"]:
                    best = row
            total += best["delta"]
        totals[i] = total
    return totals


def empirical_pvalue(stat, background):
    return (np.count_nonzero(background >= stat) + 1.0) / (len(background) + 1.0)


def fisher_method(p_values):
    stat = -2.0 * sum(math.log(p) for p in p_values)
    return float(chi2.sf(stat, 2 * len(p_values)))


def main():
    parser = argparse.ArgumentParser(description="UTG cross-detector residual test.")
    parser.add_argument("--data-dir", default=".")
    parser.add_argument("--events", nargs="*", default=list(EVENTS.keys()))
    parser.add_argument("--n-trials", type=int, default=200)
    args = parser.parse_args()

    base_dir = Path(args.data_dir)
    events = [prepare_event(base_dir, name, EVENTS[name]) for name in args.events]
    rows = [on_source_best(event) for event in events]
    on_total = float(sum(row["delta"] for row in rows))
    bg = background_trials(events, args.n_trials, 12345)
    joint_p = empirical_pvalue(on_total, bg)
    joint_z = (on_total - float(np.mean(bg))) / float(np.std(bg, ddof=1))

    per_p = []
    for event, row in zip(events, rows):
        local_bg = background_trials([event], args.n_trials, 54321)
        p_evt = empirical_pvalue(row["delta"], local_bg)
        per_p.append(p_evt)
        print(
            f"{event['name']}: p={p_evt:.6e} delta={row['delta']:.6e} "
            f"beta={row['beta']:.3f} tail_tau={row['tail_tau_s']:.3f}s "
            f"amp={row['amp']:.6e} window=({row['start_after']:.3f},{row['end_after']:.3f})s"
        )

    print()
    print(f"joint_p={joint_p:.6e}")
    print(f"joint_z={joint_z:.6e}")
    print(f"fisher_per_event_p={fisher_method(per_p):.6e}")


if __name__ == "__main__":
    main()
