import argparse
import math
from pathlib import Path

import numpy as np

import utg_cross_residual_two_channel_scaling_test as twoch


def rankdata(values):
    order = np.argsort(values)
    ranks = np.empty(len(values), dtype=np.float64)
    i = 0
    while i < len(values):
        j = i
        while j + 1 < len(values) and values[order[j + 1]] == values[order[i]]:
            j += 1
        rank = 0.5 * (i + j) + 1.0
        ranks[order[i : j + 1]] = rank
        i = j + 1
    return ranks


def spearman_rho(x, y):
    rx = rankdata(np.asarray(x, dtype=np.float64))
    ry = rankdata(np.asarray(y, dtype=np.float64))
    rx -= np.mean(rx)
    ry -= np.mean(ry)
    denom = math.sqrt(float(np.dot(rx, rx) * np.dot(ry, ry)))
    if denom == 0.0:
        return np.nan
    return float(np.dot(rx, ry) / denom)


def empirical_negative_correlation_pvalue(x, y, n_trials, seed):
    obs = spearman_rho(x, y)
    rng = np.random.default_rng(seed)
    le = 0
    y = np.asarray(y, dtype=np.float64)
    for _ in range(n_trials):
        rho = spearman_rho(x, y[rng.permutation(len(y))])
        if rho <= obs:
            le += 1
    return obs, (le + 1.0) / (n_trials + 1.0)


def event_row(base_dir, event_name, lambda_core):
    row = twoch.event_row(base_dir, event_name)
    total = row["coherent_predictor"] + lambda_core * row["morph_predictor"]
    return {
        "event": event_name,
        "two_channel_total": total,
        "abs_dphi_pi": abs(row["dphi_pi"]),
        "dphi_pi": row["dphi_pi"],
        "delta": row["delta"],
    }


def main():
    parser = argparse.ArgumentParser(
        description="Test the UTG phase-strength law: stronger total two-channel source strength predicts smaller phase mismatch."
    )
    parser.add_argument("--data-dir", default=".")
    parser.add_argument(
        "--events",
        nargs="*",
        default=[
            "GW150914",
            "GW151226",
            "GW170104",
            "GW170608",
            "GW170823",
            "GW200129_065458",
            "GW200128_022011",
            "GW200209_085452",
            "GW200210_092254",
            "GW200311_115853",
            "GW200219_094415",
            "GW200316_215756",
            "GW200220_061928",
            "GW191109_010717",
            "GW191127_050227",
            "GW200208_130117",
            "GW200216_220804",
            "GW200220_124850",
            "GW200224_222234",
            "GW200225_060421",
        ],
    )
    parser.add_argument(
        "--calibration-events",
        nargs="*",
        default=list(twoch.CORE_EVENTS),
    )
    parser.add_argument("--n-trials", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=12345)
    args = parser.parse_args()

    base_dir = Path(args.data_dir)
    calib_rows = [twoch.event_row(base_dir, e) for e in list(dict.fromkeys(args.calibration_events + args.events))]
    lambda_core, coherent_scale, morph_scale = twoch.calibrate_lambda(calib_rows, args.calibration_events)
    rows = [event_row(base_dir, e, lambda_core) for e in args.events]

    x = np.array([row["two_channel_total"] for row in rows], dtype=np.float64)
    y = np.array([row["abs_dphi_pi"] for row in rows], dtype=np.float64)
    rho, p = empirical_negative_correlation_pvalue(x, y, args.n_trials, args.seed)

    print("Independent UTG phase-strength law:")
    print("stronger total two-channel source strength => smaller abs(dphi_pi)")
    print(f"lambda_core={lambda_core:.6e}")
    print(f"core_coherent_median={coherent_scale:.6e}")
    print(f"core_morph_median={morph_scale:.6e}")
    print()
    print("Event ranking by abs(dphi_pi):")
    for row in sorted(rows, key=lambda item: item["abs_dphi_pi"], reverse=True):
        print(
            f"{row['event']}: abs_dphi_pi={row['abs_dphi_pi']:.6e} total={row['two_channel_total']:.6e} "
            f"dphi_pi={row['dphi_pi']:+.6f} delta={row['delta']:.6e}"
        )
    print()
    print("Event ranking by total two-channel source strength:")
    for row in sorted(rows, key=lambda item: item["two_channel_total"], reverse=True):
        print(
            f"{row['event']}: total={row['two_channel_total']:.6e} abs_dphi_pi={row['abs_dphi_pi']:.6e}"
        )
    print()
    print(f"spearman_rho={rho:.6e}")
    print(f"empirical_negative_correlation_p={p:.6e}")


if __name__ == "__main__":
    main()
