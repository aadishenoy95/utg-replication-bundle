import argparse
import math
from pathlib import Path

import numpy as np
from scipy import signal

import utg_cross_detector_residual_test as cross
import utg_cross_residual_complex_impulse_scaling_test as cx


PHASE_CENTER_RAD = 0.13566981938455774
PHASE_SIGMA_RAD = 0.6
CORE_EVENTS = ("GW170729", "GW170814", "GW170818")


def rankdata(values):
    order = np.argsort(values)
    ranks = np.empty(len(values), dtype=np.float64)
    i = 0
    while i < len(values):
        j = i
        while j + 1 < len(values) and values[order[j + 1]] == values[order[i]]:
            j += 1
        rank = 0.5 * (i + j) + 1.0
        ranks[order[i : j + 1]] = rank
        i = j + 1
    return ranks


def spearman_rho(x, y):
    rx = rankdata(np.asarray(x, dtype=np.float64))
    ry = rankdata(np.asarray(y, dtype=np.float64))
    rx -= np.mean(rx)
    ry -= np.mean(ry)
    denom = math.sqrt(float(np.dot(rx, rx) * np.dot(ry, ry)))
    if denom == 0.0:
        return np.nan
    return float(np.dot(rx, ry) / denom)


def empirical_positive_correlation_pvalue(x, y, n_trials, seed):
    obs = spearman_rho(x, y)
    rng = np.random.default_rng(seed)
    ge = 0
    y = np.asarray(y, dtype=np.float64)
    for _ in range(n_trials):
        rho = spearman_rho(x, y[rng.permutation(len(y))])
        if rho >= obs:
            ge += 1
    return obs, (ge + 1.0) / (n_trials + 1.0)


def wrap_phase_pi(x):
    return 0.5 * math.atan2(math.sin(2.0 * x), math.cos(2.0 * x))


def morphology_proxy(residual, fs):
    dt = 1.0 / fs
    env = np.abs(signal.hilbert(residual))
    env_rms = math.sqrt(float(np.mean(env * env)))
    if env_rms == 0.0:
        return 0.0
    env = env / env_rms
    d2 = np.gradient(np.gradient(env, dt), dt)

    window = signal.windows.tukey(len(residual), alpha=0.25)
    spec = np.fft.rfft(residual * window)
    freq = np.fft.rfftfreq(len(residual), d=dt)
    power = np.abs(spec) ** 2
    total_power = float(np.sum(power))
    if total_power == 0.0:
        return 0.0
    centroid = float(np.sum(freq * power) / total_power)
    spread = math.sqrt(float(np.sum(((freq - centroid) ** 2) * power) / total_power))
    roughness = float(np.trapezoid(np.abs(d2), dx=dt))
    amp = float(np.mean(residual * residual))
    return amp * spread * roughness


def event_row(base_dir, event_name):
    cfg = cross.EVENTS[event_name]
    event = cross.prepare_event(base_dir, event_name, cfg)
    row = cross.on_source_best(event)

    fs = event["fs"]
    start_idx = event["merger_idx"] + int(round(row["start_after"] * fs))
    end_idx = event["merger_idx"] + int(round(row["end_after"] * fs))
    h1_seg = event["h1"][start_idx:end_idx]
    l1_seg = event["l1"][start_idx:end_idx]

    q_h1 = cx.complex_impulse(h1_seg, fs)
    q_l1 = cx.complex_impulse(l1_seg, fs)
    q_h1_phase = math.atan2(q_h1.imag, q_h1.real)
    q_l1_phase = math.atan2(q_l1.imag, q_l1.real)
    dphi_pi = wrap_phase_pi((q_h1_phase - row["beta"] * q_l1_phase) - PHASE_CENTER_RAD)
    phase_gate = math.exp(-(dphi_pi * dphi_pi) / (2.0 * PHASE_SIGMA_RAD * PHASE_SIGMA_RAD))
    coherent = ((abs(q_h1) ** 2) + (abs(row["beta"]) ** 2) * (abs(q_l1) ** 2)) * phase_gate

    h1_w = cross.whiten(h1_seg, fs, *event["psd_h1"])
    l1_w = cross.whiten(l1_seg, fs, *event["psd_h1"])
    residual = h1_w - row["beta"] * l1_w
    morph = morphology_proxy(residual, fs)

    return {
        "event": event_name,
        "delta": row["delta"],
        "beta": row["beta"],
        "coherent_predictor": coherent,
        "morph_predictor": morph,
        "dphi_pi": dphi_pi,
        "phase_gate": phase_gate,
    }


def calibrate_lambda(rows, core_events):
    core = [row for row in rows if row["event"] in core_events]
    coherent_scale = float(np.median([row["coherent_predictor"] for row in core]))
    morph_scale = float(np.median([row["morph_predictor"] for row in core]))
    if morph_scale <= 0.0:
        return 1.0, coherent_scale, morph_scale
    return coherent_scale / morph_scale, coherent_scale, morph_scale


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Test a two-channel UTG source law with a coherent impulse channel "
            "plus a broadband morphology channel."
        )
    )
    parser.add_argument("--data-dir", default=".")
    parser.add_argument(
        "--events",
        nargs="*",
        default=[
            "GW150914",
            "GW151226",
            "GW170104",
            "GW170608",
            "GW170823",
            "GW200129_065458",
            "GW200209_085452",
            "GW200210_092254",
            "GW200311_115853",
            "GW200219_094415",
        ],
    )
    parser.add_argument(
        "--calibration-events",
        nargs="*",
        default=list(CORE_EVENTS),
    )
    parser.add_argument("--n-trials", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=12345)
    args = parser.parse_args()

    base_dir = Path(args.data_dir)
    calibration_names = list(dict.fromkeys(args.calibration_events))
    event_names = list(dict.fromkeys(calibration_names + args.events))
    rows = [event_row(base_dir, e) for e in event_names]
    by_event = {row["event"]: row for row in rows}
    lam, coherent_scale, morph_scale = calibrate_lambda(rows, calibration_names)

    eval_rows = [by_event[e] for e in args.events]
    for row in eval_rows:
        row["predictor_two_channel"] = row["coherent_predictor"] + lam * row["morph_predictor"]

    deltas = np.array([row["delta"] for row in eval_rows], dtype=np.float64)
    predictors = np.array([row["predictor_two_channel"] for row in eval_rows], dtype=np.float64)
    rho, p = empirical_positive_correlation_pvalue(predictors, deltas, args.n_trials, args.seed)

    print("Frozen UTG two-channel source law:")
    print("Delta_UTG ~ coherent_channel + lambda_core * morphology_channel")
    print("coherent_channel = (|Q_H1|^2 + |beta|^2 |Q_L1|^2) * C_phi_pi")
    print("morphology_channel = residual_rms^2 * spectral_spread * envelope_roughness")
    print(f"phi_*= {PHASE_CENTER_RAD:.6f} sigma_phi={PHASE_SIGMA_RAD:.6f}")
    print(f"lambda_core={lam:.6e}")
    print(f"core_coherent_median={coherent_scale:.6e}")
    print(f"core_morph_median={morph_scale:.6e}")
    print()
    print("Event ranking by observed cross-residual delta:")
    for row in sorted(eval_rows, key=lambda item: item["delta"], reverse=True):
        print(
            f"{row['event']}: delta={row['delta']:.6e} two_channel={row['predictor_two_channel']:.6e} "
            f"coh={row['coherent_predictor']:.6e} morph={row['morph_predictor']:.6e} "
            f"beta={row['beta']:.3f} dphi_pi={row['dphi_pi']:.3f}"
        )
    print()
    print("Event ranking by two-channel predictor:")
    for row in sorted(eval_rows, key=lambda item: item["predictor_two_channel"], reverse=True):
        print(
            f"{row['event']}: two_channel={row['predictor_two_channel']:.6e} "
            f"delta={row['delta']:.6e}"
        )
    print()
    print(f"spearman_rho={rho:.6e}")
    print(f"empirical_positive_correlation_p={p:.6e}")


if __name__ == "__main__":
    main()
